//
//  main.m
//  keyboard
//
//  Created by 赵宏 on 16/8/23.
//  Copyright © 2016年 赵宏. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
