//
//  AppDelegate.h
//  keyboard
//
//  Created by 赵宏 on 16/8/23.
//  Copyright © 2016年 赵宏. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

